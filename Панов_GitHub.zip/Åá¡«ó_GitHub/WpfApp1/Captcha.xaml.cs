﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Captcha.xaml
    /// </summary>
    public partial class Captcha : Window
    {
        public Captcha()
        {
            InitializeComponent();
            GenerateCaptcha();
        }
        private string text;

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (CaptchaText.Text == text)
            {
                MessageBox.Show("Капча успешно пройдена");
                this.Close();
            }
            else
            {
                GenerateCaptcha();
            }
        }

        private void GenerateCaptcha()
        {
            CaptchaCanvas.Children.Clear();

            Random random = new Random();
            text = new string(Enumerable.Range(0, 4)
            .Select(_ => (char)random.Next('A', 'Z' + 1))
            .ToArray());

            for (int i = 0; i < text.Length; i++)
            {
                var textBlock = new TextBlock
                {
                    Text = text[i].ToString(),
                    FontSize = 30,
                    //FontWeight = FontWeights.Bold,
                    Foreground = Brushes.Black,
                    RenderTransform = new RotateTransform(random.Next(-45, 45))
                };

                Canvas.SetLeft(textBlock, 30 * i + random.Next(-5, 5));
                Canvas.SetTop(textBlock, random.Next(10, 30));
                CaptchaCanvas.Children.Add(textBlock);
            }

            //for (int i = 0; i < 30; i++)
            //{
            //    var noise = new Ellipse
            //    {
            //        Width = random.Next(2, 6),
            //        Height = random.Next(2, 6),
            //        Fill = Brushes.Gray
            //    };

            //    Canvas.SetLeft(noise, random.Next(0, (int)captcha.Width));
            //    Canvas.SetTop(noise, random.Next(0, (int)captcha.Height));
            //    captcha.Children.Add(noise);
            //}
        }
    }
}
