﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Base;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для History.xaml
    /// </summary>
    public partial class History : Window
    {
        Panov_Ohta_ParkEntities DataBase = new Panov_Ohta_ParkEntities();
        public History()
        {
            InitializeComponent();
            LoadEmployee();
        }
        public void LoadEmployee()
        {
            if (Filter.SelectedIndex == -1)
            {
                var employeeResult = DataBase.Employees.ToList();
                EmployeeList.ItemsSource = employeeResult;
            }
            if (Filter.SelectedIndex == 0)
            {
                var employeeResult = DataBase.Employees.OrderBy(x => x.Login).ToList();
                EmployeeList.ItemsSource = employeeResult;
            }
            if (Filter.SelectedIndex == 1)
            {
                var employeeResult = DataBase.Employees.OrderByDescending(x => x.Login).ToList();
                EmployeeList.ItemsSource = employeeResult;
            }
        }

        private void Quit_Click(object sender, RoutedEventArgs e)
        {
            AdminWin adminWin = new AdminWin();
            adminWin.Show();
            this.Close();
        }

        private void Filter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadEmployee();
        }
    }
}
