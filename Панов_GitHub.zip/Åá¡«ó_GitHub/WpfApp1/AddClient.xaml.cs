﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Base;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для AddClient.xaml
    /// </summary>
    public partial class AddClient : Window
    {
        Panov_Ohta_ParkEntities DataBase = new Panov_Ohta_ParkEntities();
        public AddClient()
        {
            InitializeComponent();
        }

        private void Quit_Click(object sender, RoutedEventArgs e)
        {
            SellerWindow seller = new SellerWindow();
            seller.Show();
            this.Close();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(IsCorrect() == true) // Проверка на заполненность полей
                {
                    var client = new Clients() // Добавление клиента
                    {
                        LastName = LastNameBox.Text,
                        FirstName = FirstNameBox.Text,
                        Patronymic = PatronymicBox.Text,
                        ID_Client = Convert.ToInt32(ClientCode.Text),
                        PasportSeria = Convert.ToInt32(SeriaBox.Text),
                        PasportNumber = Convert.ToInt32(NumberBox.Text),
                        BirthDate = Convert.ToDateTime(Birthdate.Text),
                        IndexMail = Convert.ToInt32(Index.Text),
                        City = CityBox.Text,
                        Street = StreetBox.Text,
                        Home = Convert.ToInt32(HomeBox.Text),
                        Apartament = Convert.ToInt32(ApartamentBox.Text),
                        Email = EmailBox.Text,
                        Password = PasswordBox.Password
                    };
                    DataBase.Clients.Add(client);
                    DataBase.SaveChanges();
                    MessageBox.Show("Клиент был добавлен");
                    SellerWindow seller = new SellerWindow();
                    seller.Show();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Введены некорректные данные");
            }
        }

        public bool IsCorrect()
        {
            if (LastNameBox.Text == string.Empty)
            {
                MessageBox.Show("Введите фамилию");
                return false;
            }
            if (FirstNameBox.Text == string.Empty)
            {
                MessageBox.Show("Введите имя");
                return false;
            }
            if (PatronymicBox.Text == string.Empty)
            {
                MessageBox.Show("Введите отчество");
                return false;
            }
            if (ClientCode.Text == string.Empty)
            {
                MessageBox.Show("Введите код клиента");
                return false;
            }
            if (SeriaBox.Text == string.Empty)
            {
                MessageBox.Show("Введите серию паспорта");
                return false;
            }
            if (NumberBox.Text == string.Empty)
            {
                MessageBox.Show("Введите номер паспорта");
                return false;
            }
            if (Birthdate.Text == string.Empty)
            {
                MessageBox.Show("Введите дату рождения");
                return false;
            }
            if (Index.Text == string.Empty)
            {
                MessageBox.Show("Введите почтоывй индекс");
                return false;
            }
            if (CityBox.Text == string.Empty)
            {
                MessageBox.Show("Введите название города");
                return false;
            }
            if (StreetBox.Text == string.Empty)
            {
                MessageBox.Show("Введите название улицы");
                return false;
            }
            if (HomeBox.Text == string.Empty)
            {
                MessageBox.Show("Введите номер дома");
                return false;
            }
            if (ApartamentBox.Text == string.Empty)
            {
                MessageBox.Show("Введите номер квартиры");
                return false;
            }
            if (EmailBox.Text == string.Empty)
            {
                MessageBox.Show("Введите логин");
                return false;
            }
            if (PasswordBox.Password == string.Empty)
            {
                MessageBox.Show("Введите пароль");
                return false;
            }           
            return true;
        }
    }
}
