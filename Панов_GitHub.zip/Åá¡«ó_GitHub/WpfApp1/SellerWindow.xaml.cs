﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Base;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для SellerWindow.xaml
    /// </summary>
    public partial class SellerWindow : Window
    {
        Panov_Ohta_ParkEntities DataBase = new Panov_Ohta_ParkEntities();
        public SellerWindow()
        {
            InitializeComponent();
            LoadClients();
        }

        private void Poisk_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadClients();
        }

        private void Quit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void AddClient_Click(object sender, RoutedEventArgs e)
        {
            AddClient addClient = new AddClient();
            addClient.Show();
            this.Close();
        }

        public void LoadClients()
        {
            DataBase = new Panov_Ohta_ParkEntities();
            if (Poisk.Text == "")
            {
                var result = DataBase.Clients.ToList();
                ClientList.ItemsSource = result;
            }
            else
            {
                var result = DataBase.Clients.Where(x => x.FirstName.Contains(Poisk.Text) ||
                x.LastName.Contains(Poisk.Text) || x.Patronymic.Contains(Poisk.Text)).ToList();
                ClientList.ItemsSource = result;
            }
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            AddOrder addOrder = new AddOrder();
            addOrder.ShowDialog();
        }
    }
}
