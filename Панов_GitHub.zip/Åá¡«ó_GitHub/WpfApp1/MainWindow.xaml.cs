﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Base.Panov_Ohta_ParkEntities DataBase = new Base.Panov_Ohta_ParkEntities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Поиск записи в БД
            var result = DataBase.Employees.FirstOrDefault(x => x.Login == Login.Text && x.Password == Password.Password);
            if (result != null) 
            {
                // Проверка на должность пользователя
                if (result.Post == "Администратор")
                {
                    AdminWin adminWin = new AdminWin();
                    adminWin.Show();
                    this.Close();
                }
                if (result.Post == "Продавец" || result.Post == "Старший смены")
                {
                    SellerWindow sellerWindow = new SellerWindow();
                    sellerWindow.Show();
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль");
                Captcha captcha = new Captcha();
                captcha.ShowDialog();
            }
        }
    }
}
