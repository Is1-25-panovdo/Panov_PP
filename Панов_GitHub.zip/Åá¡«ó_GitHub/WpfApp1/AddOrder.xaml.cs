﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Base;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для AddOrder.xaml
    /// </summary>
    public partial class AddOrder : Window
    {
        Panov_Ohta_ParkEntities DataBase = new Panov_Ohta_ParkEntities();
        Clients clients;
        Services services;
        public AddOrder()
        {
            InitializeComponent();
            LoadClients();
        }

        public void LoadClients()
        {
            if (ClientsPoisk.Text == "")
            {
                ClientsList.ItemsSource = DataBase.Clients.ToList();
            }
            else
            {
                var result = DataBase.Clients.Where(x => x.FirstName.Contains(ClientsPoisk.Text) ||
                x.LastName.Contains(ClientsPoisk.Text) || x.Patronymic.Contains(ClientsPoisk.Text)).ToList();
                ClientsList.ItemsSource = result;
            }
            if (ServicePoisk.Text == "")
            {
                ServicesList.ItemsSource = DataBase.Services.ToList();
            }
            else
            {
                var result = DataBase.Services.Where(x => x.ServiceName.Contains(ServicePoisk.Text));
                ServicesList.ItemsSource = result.ToList();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ClientsList.SelectedIndex != -1 && ServicesList.SelectedIndex != -1 &&
                    TimeBox.Text != "" && MinOrHrs.SelectedIndex != -1)
                    //Проверка на выбранного пользователя и услуги
                {
                    int idClient = clients.ID_Client;
                    int idService = services.ID;
                    string minOrHrs = "";
                    if(MinOrHrs.SelectedIndex == 0)
                    {
                        minOrHrs = "Минуты";
                    }
                    if (MinOrHrs.SelectedIndex == 1)
                    {
                        minOrHrs = "Часы";
                    }
                    var order = new Orders //Создание записи о заказе
                    {
                        CreateDate = DateTime.Now,
                        OrderTime = DateTime.Now.TimeOfDay,
                        ClientID = idClient,
                        Status = "Новая",
                        TimeQuantity = Convert.ToInt32(TimeBox.Text),
                        MinsOrHours = minOrHrs
                    };
                    // Добавление записи и сохранение в БД
                    DataBase.Orders.Add(order);
                    DataBase.SaveChanges();

                    var orderAndServices = new OrdersServices
                    {
                        OrderCodeID = order.ID_Order,
                        ServiceID = services.ID
                    };
                    DataBase.OrdersServices.Add(orderAndServices);
                    DataBase.SaveChanges();
                    MessageBox.Show("Заказ был успешно создан");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Не все данные были введены");
                }     
            }
            catch
            {
                MessageBox.Show("Введены некорректные данные");
            }
        }

        private void Quit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ClientsBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadClients();
        }

        private void ServiceBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadClients();
        }

        private void ClientsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                clients = (sender as ComboBox).SelectedItem as Clients;
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ServicesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                services = (sender as ComboBox).SelectedItem as Services;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
